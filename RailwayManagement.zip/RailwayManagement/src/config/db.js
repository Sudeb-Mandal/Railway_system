const mysql = require('mysql2');
const dotenv = require('dotenv');
dotenv.config();

let db;

function connectDB() {
    db = mysql.createConnection({
        host: '127.0.0.1',
        user: 'root',
        password: process.env.DB_PASSWORD,  // This comes from the .env file
        database: 'railway_system'          // The correct database name
    });

    db.connect((err) => {
        if (err) {
            console.error('Error connecting to the database:', err.message);
            setTimeout(connectDB, 2000);  // Retry after 2 seconds if there is an error
        } else {
            console.log('Connected to MySQL database');
        }
    });

    db.on('error', (err) => {
        console.error('MySQL error:', err.message);
        if (err.code === 'PROTOCOL_ENQUEUE_AFTER_FATAL_ERROR') {
            console.log('Resetting MySQL connection...');
            db.destroy();  // Destroy the old connection
            connectDB();  // Reconnect to MySQL
        }
    });
}

connectDB(); // Initial connection

module.exports = db;
