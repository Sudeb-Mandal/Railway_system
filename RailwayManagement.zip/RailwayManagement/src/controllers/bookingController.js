const db = require('../config/db');

exports.bookSeat = (req, res) => {
    const { train_id } = req.body;
    const userId = req.user.id; // User ID from the token

    const queryCheckAvailability = `SELECT available_seats FROM trains WHERE id = ?`;
    db.query(queryCheckAvailability, [train_id], (err, result) => {
        if (err) {
            return res.status(500).send({ message: "Error checking availability", error: err });
        }

        if (result.length === 0 || result[0].available_seats === 0) {
            return res.status(400).send({ message: "No available seats" });
        }

        // Update seat availability
        const updateQuery = `UPDATE trains SET available_seats = available_seats - 1 WHERE id = ?`;
        db.query(updateQuery, [train_id], (updateErr) => {
            if (updateErr) {
                return res.status(500).send({ message: "Error updating seats", error: updateErr });
            }

            // Insert booking record
            const bookingQuery = `INSERT INTO bookings (user_id, train_id) VALUES (?, ?)`;
            db.query(bookingQuery, [userId, train_id], (bookingErr, bookingResult) => {
                if (bookingErr) {
                    return res.status(500).send({ message: "Error booking seat", error: bookingErr });
                }

                res.send({ message: "Seat booked successfully", bookingId: bookingResult.insertId });
            });
        });
    });
};

exports.getBookingDetails = (req, res) => {
    const bookingId = req.params.id;
    const userId = req.user.id; // User ID from the token

    const query = `SELECT * FROM bookings WHERE id = ? AND user_id = ?`;
    db.query(query, [bookingId, userId], (err, result) => {
        if (err) {
            return res.status(500).send({ message: "Error fetching booking details", error: err });
        }

        if (result.length === 0) {
            return res.status(404).send({ message: "Booking not found" });
        }

        res.send(result[0]);
    });
};
