
const db = require('../config/db');

exports.addTrain = (req, res) => {
    const { name, source, destination, total_seats } = req.body;

    const query = `INSERT INTO trains (name, source, destination, total_seats, available_seats) VALUES (?, ?, ?, ?, ?)`;
    db.query(query, [name, source, destination, total_seats, total_seats], (err, result) => {
        if (err) {
            return res.status(500).send({ message: "Error adding train", error: err });
        }
        res.status(201).send({ message: "Train added successfully", trainId: result.insertId });
    });
};



exports.getTrainAvailability = (req, res) => {
    const { source, destination } = req.query;

    console.log("Received Request:", source, destination);  // Debugging line

    const sql = "SELECT * FROM trains WHERE source = ? AND destination = ?";
    db.query(sql, [source, destination], (err, results) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ message: "Error fetching train data" });
        }

        console.log("Database Response:", results);  // Debugging line

        res.json(results);
    });
};

// src/controllers/trainController.js

exports.getAllTrains = (req, res) => {
    // Sample response, replace with actual DB logic
    res.json({ message: 'List of all trains' });
};

