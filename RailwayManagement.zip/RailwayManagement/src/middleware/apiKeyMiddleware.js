// src/middleware/apiKeyMiddleware.js

const API_KEY = process.env.ADMIN_API_KEY; // Fetch the API key from the .env file

// Middleware to protect admin routes
const verifyApiKey = (req, res, next) => {
    const apiKey = req.headers['api-key'];

    if (!apiKey) {
        return res.status(400).send({ message: 'API key is missing' });
    }

    if (apiKey !== API_KEY) {
        return res.status(403).send({ message: 'Invalid API key' });
    }

    next(); 
};

module.exports = verifyApiKey;
