// src/routes/trainRoutes.js

const express = require('express');
const router = express.Router();
const trainController = require('../controllers/trainController');

// Define a sample route
router.get('/all', trainController.getAllTrains);

module.exports = router;  
